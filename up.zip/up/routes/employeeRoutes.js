const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');

// Create Employee
router.post('/', async (req, res) => {
    const { name, email, position } = req.body;
    const employee = new Employee({ name, email, position });
    await employee.save();
    res.json(employee);
});

// Get all Employees
router.get('/', async (req, res) => {
    const employees = await Employee.find();
    res.json(employees);
});

// Update Employee
router.put('/:id', async (req, res) => {
    const { name, email, position } = req.body;
    const employee = await Employee.findByIdAndUpdate(req.params.id, { name, email, position }, { new: true });
    res.json(employee);
});

// Delete Employee
router.delete('/:id', async (req, res) => {
    await Employee.findByIdAndDelete(req.params.id);
    res.json({ message: 'Employee Deleted' });
});

module.exports = router;

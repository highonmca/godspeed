const employeeForm = document.getElementById('employeeForm');
const employeeList = document.getElementById('employeeList');

let employees = JSON.parse(localStorage.getItem('employees')) || [];

function saveEmployees() {
    localStorage.setItem('employees', JSON.stringify(employees));
}

function renderEmployees() {
    employeeList.innerHTML = '';

    employees.forEach((employee, index) => {
        const li = document.createElement('li');
        li.innerHTML = `
            ${employee.name} - ${employee.email} - ${employee.position}
            <button class="edit" onclick="editEmployee(${index})">Edit</button>
            <button onclick="deleteEmployee(${index})">Delete</button>
        `;
        employeeList.appendChild(li);
    });
}

employeeForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const position = document.getElementById('position').value.trim();

    if (name && email && position) {
        employees.push({ name, email, position });
        saveEmployees();
        renderEmployees();
        employeeForm.reset();
    }
});

function deleteEmployee(index) {
    if (confirm('Are you sure you want to delete this employee?')) {
        employees.splice(index, 1);
        saveEmployees();
        renderEmployees();
    }
}

function editEmployee(index) {
    const employee = employees[index];

    document.getElementById('name').value = employee.name;
    document.getElementById('email').value = employee.email;
    document.getElementById('position').value = employee.position;

    employees.splice(index, 1); // remove it first
    saveEmployees();
    renderEmployees();
}

renderEmployees();

import React from 'react';
import axios from 'axios';

const EmployeeList = ({ employees, fetchEmployees }) => {

    const deleteEmployee = async (id) => {
        await axios.delete(`http://localhost:5000/api/employees/${id}`);
        fetchEmployees();
    };

    return (
        <div>
            {employees.map(emp => (
                <div key={emp._id}>
                    <h3>{emp.name} - {emp.position}</h3>
                    <p>{emp.email}</p>
                    <button onClick={() => deleteEmployee(emp._id)}>Delete</button>
                </div>
            ))}
        </div>
    );
};

export default EmployeeList;

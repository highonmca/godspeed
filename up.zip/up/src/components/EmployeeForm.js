import React, { useState } from 'react';
import axios from 'axios';

const EmployeeForm = ({ fetchEmployees }) => {
    const [formData, setFormData] = useState({ name: '', email: '', position: '' });

    const handleChange = (e) => {
        setFormData({...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('http://localhost:5000/api/employees', formData);
        fetchEmployees();
        setFormData({ name: '', email: '', position: '' });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
            <input name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
            <input name="position" placeholder="Position" value={formData.position} onChange={handleChange} required />
            <button type="submit">Add Employee</button>
        </form>
    );
};

export default EmployeeForm;

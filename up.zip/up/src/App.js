import React, { useEffect, useState } from 'react';
import axios from 'axios';
import EmployeeForm from './components/EmployeeForm';
import EmployeeList from './components/EmployeeList';

function App() {
  const [employees, setEmployees] = useState([]);

  const fetchEmployees = async () => {
    const res = await axios.get('http://localhost:5000/api/employees');
    setEmployees(res.data);
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  return (
      <div className="App">
        <h1>Employee Record Management</h1>
        <EmployeeForm fetchEmployees={fetchEmployees} />
        <EmployeeList employees={employees} fetchEmployees={fetchEmployees} />
      </div>
  );
}

export default App;

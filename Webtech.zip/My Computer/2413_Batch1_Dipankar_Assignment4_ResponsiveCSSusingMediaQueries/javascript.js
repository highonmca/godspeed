document.addEventListener("DOMContentLoaded", function () {
    // Dropdown Toggle Functionality
    document.querySelectorAll(".nav-elements nav ul li").forEach((item) => {
      item.addEventListener("click", function () {
        this.classList.toggle("active");
      });
    });

    // Dropdown Toggle Functionality
    function toggleDropdown() {
      let content = document.getElementById("dropdownContent");
      content.classList.toggle("active");
      let navContent = document.getElementById("navContainer");
      navContent.classList.toggle("not-active");
  }

  document.querySelector(".dropdown").addEventListener("click", toggleDropdown);


     // Sidebar Active Link Functionality
  const sidebarLinks = document.querySelectorAll(".sidebar ul li a");
  sidebarLinks.forEach((link) => {
    link.addEventListener("click", function (event) {
      // Remove active class from all links
      sidebarLinks.forEach((item) => {
        item.classList.remove("active");
        item.parentElement.style.backgroundColor = "";
        item.style.color = "";
      });
      
      // Add active class to the clicked link
      this.classList.add("active");
      this.parentElement.style.backgroundColor = "#04aa6d";
      this.style.color = "#fff";
    });
  });
  
    // Navigation Buttons
  document.querySelectorAll(".content-box .button").forEach((button) => {
    button.addEventListener("click", function () {
      const direction = this.textContent.trim();
      let activeIndex = Array.from(sidebarLinks).findIndex((link) => link.classList.contains("active"));

      if (direction.includes("Next")) {
        alert("Navigating to the next section...");
        if (activeIndex < sidebarLinks.length - 1) {
          sidebarLinks[activeIndex].classList.remove("active");
          sidebarLinks[activeIndex].parentElement.style.backgroundColor = "";
          sidebarLinks[activeIndex].style.color = "";
          
          activeIndex++;
          sidebarLinks[activeIndex].classList.add("active");
          sidebarLinks[activeIndex].parentElement.style.backgroundColor = "#04aa6d";
          sidebarLinks[activeIndex].style.color = "#fff";
          sidebarLinks[activeIndex].click();
        }
      } else if (direction.includes("Previous")) {
        alert("Navigating to the previous section...");
        if (activeIndex > 0) {
          sidebarLinks[activeIndex].classList.remove("active");
          sidebarLinks[activeIndex].parentElement.style.backgroundColor = "";
          sidebarLinks[activeIndex].style.color = "";
          
          activeIndex--;
          sidebarLinks[activeIndex].classList.add("active");
          sidebarLinks[activeIndex].parentElement.style.backgroundColor = "#04aa6d";
          sidebarLinks[activeIndex].style.color = "#fff";
          sidebarLinks[activeIndex].click();
        }
      }
    });
  });

  
    // "Try it Yourself" Button
    document.querySelectorAll(".example .button").forEach((button) => {
      button.addEventListener("click", function () {
        alert("Opening Try it Yourself editor...");
        // Implement redirection or opening editor functionality
      });
    });
  
    // Sign Up & Log In Buttons
    document.querySelector(".sign-up").addEventListener("click", function () {
      alert("Redirecting to Sign Up page...");
    });
  
    document.querySelector(".log-in").addEventListener("click", function () {
      alert("Redirecting to Log In page...");
    });


     // Key-down event listener for Enter key
     document.getElementById("textInput").addEventListener("keydown", function (event) {
      if (event.key === "Enter") {
        alert("Enter key pressed: " + this.value);
        this.value = ""; // Clear input after pressing Enter
      }
    });

    document.getElementById("textInput").addEventListener("dblclick", function () {
      alert("Input field double-clicked!");
    });
  });
  
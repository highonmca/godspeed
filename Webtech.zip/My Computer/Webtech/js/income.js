// Handle Income Form Submission
const incomeForm = document.getElementById('incomeForm');
const incomeList = document.getElementById('incomeList');

// Load existing income from localStorage
function loadIncome() {
    const income = JSON.parse(localStorage.getItem('income')) || [];
    incomeList.innerHTML = '';
    income.forEach(entry => {
        const li = document.createElement('li');
        li.textContent = `${entry.source} - $${entry.amount} - ${entry.category}`;
        incomeList.appendChild(li);
    });
}

// Add income to localStorage and update list
incomeForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const source = document.getElementById('income-source').value;
    const amount = parseFloat(document.getElementById('income-amount').value);
    const category = document.getElementById('income-category').value;

    if (!source || !amount || !category) {
        alert("Please fill in all fields!");
        return;
    }

    // Get current income from localStorage or set to an empty array
    const income = JSON.parse(localStorage.getItem('income')) || [];
    income.push({ source, amount, category });

    // Save the updated income back to localStorage
    localStorage.setItem('income', JSON.stringify(income));

    // Reload income to show the updated list
    loadIncome();

    // Clear the form fields
    incomeForm.reset();
});

// Initialize the page by loading existing income
loadIncome();

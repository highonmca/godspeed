// Handle Expense Form Submission
const expenseForm = document.getElementById('expenseForm');
const expenseList = document.getElementById('expenseList');

// Load existing expenses from localStorage
function loadExpenses() {
    const expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    expenseList.innerHTML = '';
    expenses.forEach(expense => {
        const li = document.createElement('li');
        li.textContent = `${expense.name} - $${expense.amount} - ${expense.category}`;
        expenseList.appendChild(li);
    });
}

// Add expense to localStorage and update list
expenseForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('expense-name').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;

    if (!name || !amount || !category) {
        alert("Please fill in all fields!");
        return;
    }

    // Get current expenses from localStorage or set to an empty array
    const expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    expenses.push({ name, amount, category });

    // Save the updated list back to localStorage
    localStorage.setItem('expenses', JSON.stringify(expenses));

    // Reload expenses to show the updated list
    loadExpenses();

    // Clear the form fields
    expenseForm.reset();
});

// Initialize the page by loading existing expenses
loadExpenses();

// Populate the Reports Table with Data
function populateReports() {
    const expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    const income = JSON.parse(localStorage.getItem('income')) || [];

    const reportsTableBody = document.getElementById('reportsTableBody');
    reportsTableBody.innerHTML = ''; // Clear existing rows

    // Group by category
    const reportData = {};

    expenses.forEach(expense => {
        if (!reportData[expense.category]) {
            reportData[expense.category] = { expense: 0, income: 0 };
        }
        reportData[expense.category].expense += expense.amount;
    });

    income.forEach(entry => {
        if (!reportData[entry.category]) {
            reportData[entry.category] = { expense: 0, income: 0 };
        }
        reportData[entry.category].income += entry.amount;
    });

    let totalIncome = 0;
    let totalExpense = 0;

    // Populate the table
    for (const category in reportData) {
        const balance = reportData[category].income - reportData[category].expense;
        totalIncome += reportData[category].income;
        totalExpense += reportData[category].expense;

        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${category}</td>
            <td><span class="income-text">$${reportData[category].income.toFixed(2)}</span><input type="number" class="edit-income" value="${reportData[category].income}" style="display:none;"></td>
            <td><span class="expense-text">$${reportData[category].expense.toFixed(2)}</span><input type="number" class="edit-expense" value="${reportData[category].expense}" style="display:none;"></td>
            <td class="balance-text">$${balance.toFixed(2)}</td>
            <td>
                <button class="edit-btn">Edit</button>
                <button class="save-btn" style="display:none;">Save</button>
                <button class="delete-btn" style="background-color:red; color:white;">Delete</button>
            </td>
        `;

        reportsTableBody.appendChild(row);

        const editBtn = row.querySelector('.edit-btn');
        const saveBtn = row.querySelector('.save-btn');
        const deleteBtn = row.querySelector('.delete-btn');
        const incomeText = row.querySelector('.income-text');
        const expenseText = row.querySelector('.expense-text');
        const incomeInput = row.querySelector('.edit-income');
        const expenseInput = row.querySelector('.edit-expense');
        const balanceCell = row.querySelector('.balance-text');

        editBtn.addEventListener('click', () => {
            incomeText.style.display = 'none';
            expenseText.style.display = 'none';
            incomeInput.style.display = 'inline-block';
            expenseInput.style.display = 'inline-block';
            editBtn.style.display = 'none';
            saveBtn.style.display = 'inline-block';
        });

        saveBtn.addEventListener('click', () => {
            const newIncome = parseFloat(incomeInput.value) || 0;
            const newExpense = parseFloat(expenseInput.value) || 0;
            const newBalance = newIncome - newExpense;

            // Update text
            incomeText.textContent = `$${newIncome.toFixed(2)}`;
            expenseText.textContent = `$${newExpense.toFixed(2)}`;
            balanceCell.textContent = `$${newBalance.toFixed(2)}`;

            // Toggle visibility
            incomeText.style.display = 'inline-block';
            expenseText.style.display = 'inline-block';
            incomeInput.style.display = 'none';
            expenseInput.style.display = 'none';
            editBtn.style.display = 'inline-block';
            saveBtn.style.display = 'none';

            // Update localStorage
            updateLocalStorage(category, newIncome, newExpense);

            // Re-populate to update total balance
            populateReports();
        });

        deleteBtn.addEventListener('click', () => {
            if (confirm(`Are you sure you want to delete "${category}"?`)) {
                deleteFromLocalStorage(category);
                populateReports();
            }
        });
    }

    // Add Total Balance Row at the bottom
    const totalBalance = totalIncome - totalExpense;
    const totalRow = document.createElement('tr');
    totalRow.innerHTML = `
        <td><strong>Total</strong></td>
        <td></td>
        <td></td>
        <td><strong>$${totalBalance.toFixed(2)}</strong></td>
        <td></td>
    `;
    reportsTableBody.appendChild(totalRow);
}


// Update localStorage after edit
function updateLocalStorage(category, newIncome, newExpense) {
    let expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    let income = JSON.parse(localStorage.getItem('income')) || [];

    // Remove old entries for this category
    expenses = expenses.filter(e => e.category !== category);
    income = income.filter(i => i.category !== category);

    // Add new updated entries
    if (newExpense > 0) {
        expenses.push({ category: category, amount: newExpense });
    }
    if (newIncome > 0) {
        income.push({ category: category, amount: newIncome });
    }

    // Save back to localStorage
    localStorage.setItem('expenses', JSON.stringify(expenses));
    localStorage.setItem('income', JSON.stringify(income));
}

// Delete from localStorage
function deleteFromLocalStorage(category) {
    let expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    let income = JSON.parse(localStorage.getItem('income')) || [];

    expenses = expenses.filter(e => e.category !== category);
    income = income.filter(i => i.category !== category);

    localStorage.setItem('expenses', JSON.stringify(expenses));
    localStorage.setItem('income', JSON.stringify(income));
}

// Call populateReports function when the page loads
populateReports();

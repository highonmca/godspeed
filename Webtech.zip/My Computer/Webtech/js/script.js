// Handle login form submission
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();

        if (email === '' || password === '') {
            alert('Please fill in all fields.');
            return;
        }

        // Fetch users from localStorage
        let users = JSON.parse(localStorage.getItem('users')) || [];

        // Check if email and password match any user
        const matchedUser = users.find(user => user.email === email && user.password === password);

        if (matchedUser) {
            // Save the current logged-in user's email
            localStorage.setItem('currentUser', matchedUser.email);
        
            alert('Login successful!');
            window.location.href = '../pages/dashboard.html';
        } else {
            alert('Invalid email or password.');
        }
    });
}

// Handle register form submission
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        const confirmPassword = document.getElementById('confirmPassword').value.trim();

        if (name === '' || email === '' || password === '' || confirmPassword === '') {
            alert('Please fill in all fields.');
            return;
        }

        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }

        // Fetch users from localStorage
        let users = JSON.parse(localStorage.getItem('users')) || [];

        // Check if email already exists
        const existingUser = users.find(user => user.email === email);
        if (existingUser) {
            alert('Email already registered. Please use another email.');
            return;
        }

        // Save new user
        const newUser = {
            name: name,
            email: email,
            password: password
        };
        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));

        alert('Registration successful!');
        // Redirect to login page
        window.location.href = 'login.html';
    });
}

// Handle Settings Page loading
document.addEventListener('DOMContentLoaded', function() {
    const settingsForm = document.getElementById('settingsForm');

    if (settingsForm) {
        const currentUserEmail = localStorage.getItem('currentUser');
        if (!currentUserEmail) {
            alert('No user logged in. Please login first.');
            window.location.href = 'login.html';
            return;
        }

        // Load current user details
        let users = JSON.parse(localStorage.getItem('users')) || [];
        const userIndex = users.findIndex(u => u.email === currentUserEmail);

        if (userIndex === -1) {
            alert('User not found. Please login again.');
            window.location.href = 'login.html';
            return;
        }

        const currentUser = users[userIndex];
        document.getElementById('username').value = currentUser.name;
        document.getElementById('email').value = currentUser.email;  // Read-only ideally
        // Leave password empty for security reasons

        // Handle settings form submit
        settingsForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const updatedUsername = document.getElementById('username').value.trim();
            const updatedPassword = document.getElementById('password').value.trim();

            if (updatedUsername === '' || updatedPassword === '') {
                alert('Please fill in all fields.');
                return;
            }

            // Update user details
            users[userIndex].name = updatedUsername;
            users[userIndex].password = updatedPassword;

            // Save back to localStorage
            localStorage.setItem('users', JSON.stringify(users));

            alert('Settings updated successfully!');
            // Optionally clear the password field
            document.getElementById('password').value = '';
        });
    }
});